// 1. feladat - Kocka felszíne

<script>


    function KockaFelszin(a) {
        let felszin = 6*a*a;
    return felszin;
}

    document.write("A kocka felszíne: "+KockaFelszin(2));
    document.write("<br>A kocka felszíne: "+KockaFelszin(3));
        document.write("<br>A kocka felszíne: " +KockaFelszin(5));


        </script>