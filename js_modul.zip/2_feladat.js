// 2. feladat - Kocka térfogata

<script>



    function KockaTerfogat(a) {
        let terfogat = a*a*a;
    return terfogat;
}

    document.write("A kocka térfogata: "+KockaTerfogat(2));
    document.write("<br>A kocka térfogata: "+KockaTerfogat(3));
        document.write("<br>A kocka térfogata: "+KockaTerfogat(5));


        </script>

