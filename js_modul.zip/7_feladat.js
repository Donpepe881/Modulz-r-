<script>

    function SzovegVisszafele(szoveg) {
        let ujSzoveg = ;
    for (let i=0; i<szoveg.length; i++) {
        ujSzoveg = szoveg[i].reversed;
    }
}

    document.write(""+SzovegVisszafele("Szeretem a programozás"));
    document.write("<br>"+SzovegVisszafele("Géza kék az ég"));
        document.write("<br>"+SzovegVisszafele("Répa, retek, mogyoró"));

        </script>
