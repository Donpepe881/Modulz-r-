<script>

// 1. feladat - Kocka felszíne


    function KockaFelszin(a) {
        let felszin = 6*a*a;
    return felszin;
}

    document.write("A kocka felszíne: "+KockaFelszin(2));
    document.write("<br>A kocka felszíne: "+KockaFelszin(3));
        document.write("<br>A kocka felszíne: " +KockaFelszin(5));


        </script>



        <script>

            function KockaTerfogat(a) {
                let terfogat = a*a*a;
            return terfogat;
}

            document.write("A kocka térfogata: "+KockaTerfogat(2));
            document.write("<br>A kocka térfogata: "+KockaTerfogat(3));
                document.write("<br>A kocka térfogata: "+KockaTerfogat(5));


                </script>

